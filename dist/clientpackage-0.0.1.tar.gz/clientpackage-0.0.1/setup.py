from setuptools import setup

setup(
    author="Hector Mandril",
    author_email="elector22@gmail.com",
    description="paquete personalizado de clases y registro de usuarios para un ecommerce",
    version="0.0.1",
    name="clientPackage",
    packages=["my_package"]
)

#python setup.py sdist